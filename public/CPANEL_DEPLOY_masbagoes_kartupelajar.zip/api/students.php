<?php
require_once __DIR__ . '/../config.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$action = $_GET['action'] ?? '';

if ($action === 'db_status') {
    $connected = false;
    $totalSiswa = 0;
    try {
        $pdo = getDbConnection();
        if ($pdo) {
            $connected = true;
            $stmt = $pdo->query("SELECT COUNT(*) as c FROM siswa");
            $totalSiswa = (int)($stmt->fetch()['c'] ?? 0);
        }
    } catch (Exception $e) {}

    echo json_encode([
        'connected' => $connected,
        'mysqlConnected' => $connected,
        'totalSiswa' => $totalSiswa,
        'dbName' => DB_NAME,
        'dbUser' => DB_USER,
        'serverTime' => date('c')
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true);

    if (!$input) {
        echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
        exit;
    }

    $lastUpdated = date('c');
    $pdo = getDbConnection();
    $mysqlOk = false;

    if ($pdo) {
        try {
            $pdo->beginTransaction();

            // 1. Simpan Profil Madrasah
            if (isset($input['madrasah']) && is_array($input['madrasah'])) {
                $m = $input['madrasah'];
                $stmtM = $pdo->prepare("INSERT INTO madrasah_info (
                    id, nama_kementerian, nsm, npsn, nama_madrasah, kemenag_wilayah, alamat,
                    kelurahan_desa, kecamatan, kota_kabupaten, provinsi, kode_pos, telepon,
                    email, website, akreditasi, motto, jabatan_penandatangan, label_id_penandatangan,
                    nama_kepala_madrasah, nip_kepala_madrasah, kota_penetapan, tanggal_penetapan,
                    tahun_pelajaran, logo_aplikasi_url, logo_kemenag_url, logo_madrasah_url,
                    stempel_url, ttd_kepala_url, updated_at
                ) VALUES (
                    1, :kemen, :nsm, :npsn, :nama, :wil, :alamat,
                    :desa, :kec, :kota, :prov, :kpos, :tel,
                    :email, :web, :akred, :motto, :jab, :lbl,
                    :kepala, :nip, :k_tetap, :t_tetap,
                    :thn, :logo_app, :logo_kemen, :logo_mad,
                    :stempel, :ttd, NOW()
                ) ON DUPLICATE KEY UPDATE
                    nama_kementerian=VALUES(nama_kementerian), nsm=VALUES(nsm), npsn=VALUES(npsn),
                    nama_madrasah=VALUES(nama_madrasah), kemenag_wilayah=VALUES(kemenag_wilayah),
                    alamat=VALUES(alamat), kelurahan_desa=VALUES(kelurahan_desa), kecamatan=VALUES(kecamatan),
                    kota_kabupaten=VALUES(kota_kabupaten), provinsi=VALUES(provinsi), kode_pos=VALUES(kode_pos),
                    telepon=VALUES(telepon), email=VALUES(email), website=VALUES(website),
                    akreditasi=VALUES(akreditasi), motto=VALUES(motto), jabatan_penandatangan=VALUES(jabatan_penandatangan),
                    label_id_penandatangan=VALUES(label_id_penandatangan), nama_kepala_madrasah=VALUES(nama_kepala_madrasah),
                    nip_kepala_madrasah=VALUES(nip_kepala_madrasah), kota_penetapan=VALUES(kota_penetapan),
                    tanggal_penetapan=VALUES(tanggal_penetapan), tahun_pelajaran=VALUES(tahun_pelajaran),
                    logo_aplikasi_url=VALUES(logo_aplikasi_url), logo_kemenag_url=VALUES(logo_kemenag_url),
                    logo_madrasah_url=VALUES(logo_madrasah_url), stempel_url=VALUES(stempel_url),
                    ttd_kepala_url=VALUES(ttd_kepala_url), updated_at=NOW()");

                $stmtM->execute([
                    ':kemen' => (string)($m['namaKementerian'] ?? 'KEMENTERIAN AGAMA REPUBLIK INDONESIA'),
                    ':nsm' => (string)($m['nsm'] ?? ''),
                    ':npsn' => (string)($m['npsn'] ?? ''),
                    ':nama' => (string)($m['namaMadrasah'] ?? ''),
                    ':wil' => (string)($m['kemenagWilayah'] ?? ''),
                    ':alamat' => (string)($m['alamat'] ?? ''),
                    ':desa' => (string)($m['kelurahanDesa'] ?? ''),
                    ':kec' => (string)($m['kecamatan'] ?? ''),
                    ':kota' => (string)($m['kotaKab'] ?? ''),
                    ':prov' => (string)($m['provinsi'] ?? ''),
                    ':kpos' => (string)($m['kodePos'] ?? ''),
                    ':tel' => (string)($m['telepon'] ?? ''),
                    ':email' => (string)($m['email'] ?? ''),
                    ':web' => (string)($m['website'] ?? ''),
                    ':akred' => (string)($m['akreditasi'] ?? 'A'),
                    ':motto' => (string)($m['motto'] ?? ''),
                    ':jab' => (string)($m['jabatanPenandatangan'] ?? 'Kepala Madrasah'),
                    ':lbl' => (string)($m['labelIdPenandatangan'] ?? 'NIP'),
                    ':kepala' => (string)($m['namaKepalaMadrasah'] ?? ''),
                    ':nip' => (string)($m['nipKepalaMadrasah'] ?? ''),
                    ':k_tetap' => (string)($m['kotaPenetapan'] ?? ''),
                    ':t_tetap' => (string)($m['tanggalPenetapan'] ?? ''),
                    ':thn' => (string)($m['tahunPelajaran'] ?? '2025/2026'),
                    ':logo_app' => (string)($m['logoAplikasiUrl'] ?? ''),
                    ':logo_kemen' => (string)($m['logoKemenagUrl'] ?? ''),
                    ':logo_mad' => (string)($m['logoMadrasahUrl'] ?? ''),
                    ':stempel' => (string)($m['stempelUrl'] ?? ''),
                    ':ttd' => (string)($m['ttdKepalaUrl'] ?? '')
                ]);
            }

            // 2. Simpan Desain Kartu
            if (isset($input['cardConfig']) && is_array($input['cardConfig'])) {
                $c = $input['cardConfig'];
                $configJson = json_encode($c, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $stmtC = $pdo->prepare("INSERT INTO pengaturan_kartu (id, theme, config_json, updated_at) VALUES (1, :theme, :cfg, NOW()) ON DUPLICATE KEY UPDATE theme=VALUES(theme), config_json=VALUES(config_json), updated_at=NOW()");
                $stmtC->execute([
                    ':theme' => (string)($c['theme'] ?? 'kemenag-classic'),
                    ':cfg' => $configJson
                ]);
            }

            // 3. Simpan Kop Surat
            if (isset($input['kopSuratConfig']) && is_array($input['kopSuratConfig'])) {
                $k = $input['kopSuratConfig'];
                $kopJson = json_encode($k, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $stmtK = $pdo->prepare("INSERT INTO kop_surat (id, config_json, updated_at) VALUES (1, :cfg, NOW()) ON DUPLICATE KEY UPDATE config_json=VALUES(config_json), updated_at=NOW()");
                $stmtK->execute([':cfg' => $kopJson]);
            }

            // 4. Simpan Siswa
            if (isset($input['students']) && is_array($input['students'])) {
                $pdo->exec("DELETE FROM siswa");
                $stmtS = $pdo->prepare("INSERT INTO siswa (
                    id, nisn, nis, nama, tempat_lahir, tanggal_lahir, jenis_kelamin, kelas, tahun_ajaran,
                    agama, alamat, nama_wali, golongan_darah, foto_url, berlaku_sampai, status, created_at, updated_at
                ) VALUES (
                    :id, :nisn, :nis, :nama, :tempat, :tanggal, :jk, :kelas, :tahun,
                    :agama, :alamat, :wali, :goldar, :foto, :berlaku, 'aktif', NOW(), NOW()
                )");

                foreach ($input['students'] as $s) {
                    if (empty($s['nama']) && empty($s['nisn']) && empty($s['nis'])) continue;
                    $stmtS->execute([
                        ':id' => (string)($s['id'] ?? uniqid('std_')),
                        ':nisn' => (string)($s['nisn'] ?? ''),
                        ':nis' => (string)($s['nis'] ?? ''),
                        ':nama' => (string)($s['nama'] ?? ''),
                        ':tempat' => (string)($s['tempatLahir'] ?? ''),
                        ':tanggal' => (string)($s['tanggalLahir'] ?? ''),
                        ':jk' => (strtoupper($s['jenisKelamin'] ?? 'L') === 'P' ? 'P' : 'L'),
                        ':kelas' => (string)($s['kelas'] ?? '1-A'),
                        ':tahun' => (string)($s['tahunAjaran'] ?? '2025/2026'),
                        ':agama' => (string)($s['agama'] ?? 'Islam'),
                        ':alamat' => (string)($s['alamat'] ?? ''),
                        ':wali' => (string)($s['namaWali'] ?? ''),
                        ':goldar' => (string)($s['golonganDarah'] ?? '-'),
                        ':foto' => (string)($s['fotoUrl'] ?? ''),
                        ':berlaku' => (string)($s['berlakuSampai'] ?? 'Selama Menjadi Siswa')
                    ]);
                }
            }

            $pdo->commit();
            $mysqlOk = true;
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            error_log("Gagal sync ke MySQL: " . $e->getMessage());
        }
    }

    // File backup lokal anti-timpa
    $dataDir = __DIR__ . '/../data';
    if (!is_dir($dataDir)) @mkdir($dataDir, 0755, true);
    $input['lastUpdated'] = $lastUpdated;
    @file_put_contents($dataDir . '/database.json', json_encode($input, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    @file_put_contents($dataDir . '/persistent_database.json', json_encode($input, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    $totalStudents = isset($input['students']) ? count($input['students']) : 0;
    echo json_encode([
        'success' => true,
        'status' => 'success',
        'message' => $mysqlOk ? 'Data tersimpan otomatis ke MySQL cPanel & Backup Lokal' : 'Data tersimpan di penyimpanan fallback',
        'mysqlConnected' => $mysqlOk,
        'lastUpdated' => $lastUpdated,
        'totalStudents' => $totalStudents
    ]);
    exit;
}

// GET REQUEST: Ambil data dari MySQL atau JSON
$response = [
    'success' => true,
    'status' => 'success',
    'mysqlConnected' => false,
    'data' => null
];

$pdo = getDbConnection();
$foundInMysql = false;

if ($pdo) {
    try {
        $mRow = $pdo->query("SELECT * FROM madrasah_info LIMIT 1")->fetch();
        if ($mRow) {
            $madrasahData = [
                'namaKementerian' => $mRow['nama_kementerian'] ?? '',
                'nsm' => $mRow['nsm'] ?? '',
                'npsn' => $mRow['npsn'] ?? '',
                'namaMadrasah' => $mRow['nama_madrasah'] ?? '',
                'namaSingkat' => $mRow['nama_singkat'] ?? '',
                'kemenagWilayah' => $mRow['kemenag_wilayah'] ?? '',
                'alamat' => $mRow['alamat'] ?? '',
                'kelurahanDesa' => $mRow['kelurahan_desa'] ?? '',
                'kecamatan' => $mRow['kecamatan'] ?? '',
                'kotaKab' => $mRow['kota_kabupaten'] ?? '',
                'provinsi' => $mRow['provinsi'] ?? '',
                'kodePos' => $mRow['kode_pos'] ?? '',
                'telepon' => $mRow['telepon'] ?? '',
                'email' => $mRow['email'] ?? '',
                'website' => $mRow['website'] ?? '',
                'akreditasi' => $mRow['akreditasi'] ?? 'A',
                'motto' => $mRow['motto'] ?? '',
                'jabatanPenandatangan' => $mRow['jabatan_penandatangan'] ?? 'Kepala Madrasah',
                'labelIdPenandatangan' => $mRow['label_id_penandatangan'] ?? 'NIP',
                'namaKepalaMadrasah' => $mRow['nama_kepala_madrasah'] ?? '',
                'nipKepalaMadrasah' => $mRow['nip_kepala_madrasah'] ?? '',
                'kotaPenetapan' => $mRow['kota_penetapan'] ?? '',
                'tanggalPenetapan' => $mRow['tanggal_penetapan'] ?? '',
                'tahunPelajaran' => $mRow['tahun_pelajaran'] ?? '2025/2026',
                'logoAplikasiUrl' => $mRow['logo_aplikasi_url'] ?? '',
                'logoKemenagUrl' => $mRow['logo_kemenag_url'] ?? '',
                'logoMadrasahUrl' => $mRow['logo_madrasah_url'] ?? '',
                'stempelUrl' => $mRow['stempel_url'] ?? '',
                'ttdKepalaUrl' => $mRow['ttd_kepala_url'] ?? ''
            ];

            // Card Config
            $cRow = $pdo->query("SELECT * FROM pengaturan_kartu LIMIT 1")->fetch();
            $cardConfigData = [];
            if ($cRow && !empty($cRow['config_json'])) {
                $cardConfigData = json_decode($cRow['config_json'], true) ?: [];
            }

            // Kop Surat
            $kRow = $pdo->query("SELECT * FROM kop_surat LIMIT 1")->fetch();
            $kopConfigData = null;
            if ($kRow && !empty($kRow['config_json'])) {
                $kopConfigData = json_decode($kRow['config_json'], true);
            }

            // Siswa
            $sRows = $pdo->query("SELECT * FROM siswa ORDER BY kelas ASC, nama ASC")->fetchAll();
            $studentsData = [];
            foreach ($sRows as $s) {
                $studentsData[] = [
                    'id' => $s['id'],
                    'nisn' => $s['nisn'],
                    'nis' => $s['nis'],
                    'nama' => $s['nama'],
                    'tempatLahir' => $s['tempat_lahir'] ?? '',
                    'tanggalLahir' => $s['tanggal_lahir'] ?? '',
                    'jenisKelamin' => $s['jenis_kelamin'] ?? 'L',
                    'kelas' => $s['kelas'] ?? '1-A',
                    'tahunAjaran' => $s['tahun_ajaran'] ?? '2025/2026',
                    'agama' => $s['agama'] ?? 'Islam',
                    'alamat' => $s['alamat'] ?? '',
                    'namaWali' => $s['nama_wali'] ?? '',
                    'golonganDarah' => $s['golongan_darah'] ?? '-',
                    'fotoUrl' => $s['foto_url'] ?? '',
                    'berlakuSampai' => $s['berlaku_sampai'] ?? 'Selama Menjadi Siswa'
                ];
            }

            $response['mysqlConnected'] = true;
            $response['data'] = [
                'madrasah' => $madrasahData,
                'cardConfig' => $cardConfigData,
                'kopSuratConfig' => $kopConfigData,
                'students' => $studentsData,
                'lastUpdated' => date('c'),
                'mysqlConnected' => true
            ];
            $foundInMysql = true;
        }
    } catch (Exception $e) {}
}

if (!$foundInMysql) {
    $fallbackFiles = [
        __DIR__ . '/../data/persistent_database.json',
        __DIR__ . '/../data/database.json',
        __DIR__ . '/../backup_data_madrasah.json'
    ];
    foreach ($fallbackFiles as $ff) {
        if (file_exists($ff)) {
            $raw = @file_get_contents($ff);
            $parsed = json_decode($raw, true);
            if ($parsed && isset($parsed['madrasah'])) {
                $response['data'] = $parsed;
                break;
            }
        }
    }
}

echo json_encode($response);
