# PANDUAN DEPLOYMENT APLIKASI KARTU PELAJAR MI DI CPANEL
Lembaga: MI TESTING UPDATE 123
NSM: 111233020084 | NPSN: 60721868
Domain Target: kartu.madrasah.sch.id

---

## 🛡️ SISTEM SINKRONISASI & PENYIMPANAN OTOMATIS KE MYSQL
Aplikasi ini sudah diprogram untuk menyimpan dan melakukan sinkronisasi otomatis ke database MySQL cPanel:
1. **Auto-Table Migration**: Skrip `config.php` dan `auto_setup.php` akan otomatis memverifikasi dan membuat tabel (`madrasah_info`, `siswa`, `pengaturan_kartu`, `kop_surat`, `activity_logs`).
2. **Instant Sync**: Setiap penambahan siswa, pembaruan identitas madrasah, atau desain kartu akan otomatis tersimpan langsung ke MySQL via REST API `api/data.php`.
3. **Anti-Timpa**: Ekstraksi ZIP baru di `public_html` tidak akan menghapus data yang telah tersimpan di MySQL.

---

## 🗄️ INFORMASI KREDENSIAL DATABASE MYSQL CPANEL
- **Database Host**: `localhost` (biasanya `localhost`)
- **Database Name**: `masbagoes_kartupelajar`
- **Database Username**: `masbagoes_kartupelajar`
- **Database Password**: `masbagus15`
- **Port**: `3306`
- **Berkas Dump SQL**: `database.sql` / `masbagoes_kartupelajar.sql`

---

## 🚀 3 LANGKAH MUDAH DEPLOY DI CPANEL:

### 1. Buat Database & User di cPanel
1. Login ke **cPanel**.
2. Buka menu **MySQL® Databases** (atau **MySQL Database Wizard**).
3. Buat database: `masbagoes_kartupelajar`
4. Buat user database: `masbagoes_kartupelajar` dengan password: `masbagus15`
5. Hubungkan user ke database dan centang **ALL PRIVILEGES** & klik **Make Changes**.

### 2. Upload & Ekstrak ZIP di File Manager
1. Buka **File Manager** di cPanel.
2. Buka folder **`public_html`** (atau folder subdomain Anda).
3. Upload berkas ZIP ini.
4. Klik kanan pada file ZIP, lalu pilih **Extract**.

### 3. Eksekusi Auto-Setup
1. Buka browser dan kunjungi:
   `https://kartu.madrasah.sch.id/auto_setup.php`
2. Anda akan melihat laporan hijau: **Status Verifikasi & Migrasi Database MySQL Otomatis**.
3. Selesai! Buka `https://kartu.madrasah.sch.id` untuk menggunakan aplikasi. Semua data akan tersimpan langsung di MySQL!
