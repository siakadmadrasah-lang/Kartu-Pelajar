<?php
/**
 * ==============================================================================
 * KONFIGURASI DATABASE MYSQL CPANEL & PLESK (PROTEKSI ANTI-HILANG DATA OTOMATIS)
 * Aplikasi: Generator Kartu Pelajar MI (Kemenag RI)
 * Database Name: masbagoes_kartupelajar
 * Database User: masbagoes_kartupelajar
 * ==============================================================================
 */

// Cek custom config lokal jika pernah disimpan sebelumnya (Anti-Timpa)
if (file_exists(__DIR__ . '/config.local.php')) {
    require_once __DIR__ . '/config.local.php';
} elseif (file_exists(__DIR__ . '/data/db_custom_config.php')) {
    require_once __DIR__ . '/data/db_custom_config.php';
}

if (!defined('DB_HOST')) define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
if (!defined('DB_NAME')) define('DB_NAME', getenv('DB_DATABASE') ?: 'masbagoes_kartupelajar');
if (!defined('DB_USER')) define('DB_USER', getenv('DB_USERNAME') ?: 'masbagoes_kartupelajar');
if (!defined('DB_PASS')) define('DB_PASS', getenv('DB_PASSWORD') ?: 'masbagus15');
if (!defined('DB_PORT')) define('DB_PORT', getenv('DB_PORT') ?: 3306);

function getDbConnection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    try {
        $dsn = "mysql:host=" . DB_HOST . ";port=" . DB_PORT . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

        // Auto-create essential tables if they do not exist
        $pdo->exec("CREATE TABLE IF NOT EXISTS madrasah_info (
          id INT(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
          nama_kementerian VARCHAR(255) DEFAULT 'KEMENTERIAN AGAMA REPUBLIK INDONESIA',
          nsm VARCHAR(50) DEFAULT NULL,
          npsn VARCHAR(50) DEFAULT NULL,
          nama_madrasah VARCHAR(255) NOT NULL,
          nama_singkat VARCHAR(100) DEFAULT NULL,
          kemenag_wilayah VARCHAR(255) DEFAULT NULL,
          alamat TEXT DEFAULT NULL,
          kelurahan_desa VARCHAR(100) DEFAULT NULL,
          kecamatan VARCHAR(100) DEFAULT NULL,
          kota_kabupaten VARCHAR(100) DEFAULT NULL,
          provinsi VARCHAR(100) DEFAULT NULL,
          kode_pos VARCHAR(20) DEFAULT NULL,
          telepon VARCHAR(50) DEFAULT NULL,
          email VARCHAR(100) DEFAULT NULL,
          website VARCHAR(100) DEFAULT NULL,
          akreditasi VARCHAR(10) DEFAULT 'A',
          motto TEXT DEFAULT NULL,
          jabatan_penandatangan VARCHAR(100) DEFAULT 'Kepala Madrasah',
          label_id_penandatangan VARCHAR(20) DEFAULT 'NIP',
          nama_kepala_madrasah VARCHAR(255) DEFAULT NULL,
          nip_kepala_madrasah VARCHAR(100) DEFAULT NULL,
          kota_penetapan VARCHAR(100) DEFAULT NULL,
          tanggal_penetapan VARCHAR(100) DEFAULT NULL,
          tahun_pelajaran VARCHAR(50) DEFAULT '2025/2026',
          judul_header_aplikasi VARCHAR(255) DEFAULT 'KARTU PELAJAR DIGITAL',
          sub_judul_header_aplikasi VARCHAR(255) DEFAULT NULL,
          badge_header_aplikasi VARCHAR(100) DEFAULT 'KEMENAG RI',
          show_madrasah_in_header TINYINT(1) DEFAULT 1,
          logo_aplikasi_url LONGTEXT DEFAULT NULL,
          logo_kemenag_url LONGTEXT DEFAULT NULL,
          logo_madrasah_url LONGTEXT DEFAULT NULL,
          logo_url LONGTEXT DEFAULT NULL,
          stempel_url LONGTEXT DEFAULT NULL,
          ttd_kepala_url LONGTEXT DEFAULT NULL,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        $pdo->exec("CREATE TABLE IF NOT EXISTS siswa (
          id VARCHAR(100) NOT NULL,
          nisn VARCHAR(50) NOT NULL,
          nis VARCHAR(50) NOT NULL,
          nama VARCHAR(255) NOT NULL,
          tempat_lahir VARCHAR(100) DEFAULT NULL,
          tanggal_lahir VARCHAR(100) DEFAULT NULL,
          jenis_kelamin VARCHAR(50) DEFAULT 'L',
          kelas VARCHAR(100) NOT NULL,
          tahun_ajaran VARCHAR(50) NOT NULL,
          agama VARCHAR(50) DEFAULT 'Islam',
          alamat TEXT DEFAULT NULL,
          nama_wali VARCHAR(255) DEFAULT NULL,
          golongan_darah VARCHAR(20) DEFAULT '-',
          foto_url LONGTEXT DEFAULT NULL,
          berlaku_sampai VARCHAR(100) DEFAULT NULL,
          status VARCHAR(20) DEFAULT 'aktif',
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (id),
          KEY idx_nisn (nisn),
          KEY idx_kelas (kelas)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        $pdo->exec("CREATE TABLE IF NOT EXISTS pengaturan_kartu (
          id INT(11) NOT NULL AUTO_INCREMENT,
          theme VARCHAR(50) DEFAULT 'kemenag-classic',
          config_json LONGTEXT DEFAULT NULL,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        $pdo->exec("CREATE TABLE IF NOT EXISTS kop_surat (
          id INT(11) NOT NULL AUTO_INCREMENT,
          config_json LONGTEXT DEFAULT NULL,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        $pdo->exec("CREATE TABLE IF NOT EXISTS activity_logs (
          id VARCHAR(100) NOT NULL,
          action VARCHAR(255) NOT NULL,
          operator VARCHAR(100) NOT NULL,
          details TEXT DEFAULT NULL,
          type VARCHAR(50) NOT NULL,
          timestamp TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    } catch (PDOException $e) {
        error_log('Koneksi MySQL gagal (' . DB_NAME . '): ' . $e->getMessage());
        $pdo = null;
    }
    return $pdo;
}
